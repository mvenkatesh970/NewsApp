# NewsApp Project
Capstone project by Group 1(Java FSD Batch 47-A).

## Members
Shivansh Mathur , <add names>

# Usage

1. There are two parts to this project. "NewsappUI" is front-end code written using Angular while rest all folders are for backend.

2. All backend folders are spring boot applications and each has to be individually run.

3. Database used in this project is MySQL. Make sure you have it installed and configure it according to "application.properties" file present in userservice folder.

4. After running all the backend folders run the frontend folder. First install the dependencies using "npm install" and then run the angular app using "ng serve -o".
