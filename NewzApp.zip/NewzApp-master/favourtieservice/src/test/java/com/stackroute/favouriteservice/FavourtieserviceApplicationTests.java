package com.stackroute.favouriteservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FavourtieserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
